import React from 'react'
import CustomComponent from '../../components/userDash/Custom'

const User = () => {
    return (
        <CustomComponent />
    )
}

export default User