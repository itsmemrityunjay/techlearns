import React from 'react'
import LearnSection from '../components/courses/Learn'

const Course = () => {
    return (
        <div><LearnSection /></div>
    )
}

export default Course